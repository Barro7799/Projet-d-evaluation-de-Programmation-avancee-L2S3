// ================================================================
// Fichier  : Livre.cpp
// Role     : DEFINITION de la classe Livre
// Exo 1    : Modele DDU
// ================================================================

#include "Livre.h"
#include <iostream>
using namespace std;

Livre::Livre() : ISSN(""), auteurs(""), titre("") {}

Livre::Livre(string issn, string aut, string tit)
    : ISSN(issn), auteurs(aut), titre(tit) {}

string Livre::getISSN()    const { return ISSN;    }
string Livre::getAuteurs() const { return auteurs; }
string Livre::getTitre()   const { return titre;   }

void Livre::setISSN(string issn)   { ISSN    = issn; }
void Livre::setAuteurs(string aut) { auteurs = aut;  }
void Livre::setTitre(string tit)   { titre   = tit;  }

Livre::~Livre() {}
