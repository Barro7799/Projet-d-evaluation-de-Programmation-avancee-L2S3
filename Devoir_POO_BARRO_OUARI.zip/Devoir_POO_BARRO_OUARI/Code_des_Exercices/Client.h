// ================================================================
// Fichier  : Client.h
// Role     : DECLARATION + DEFINITION de la classe parametree Client
// Exo 3    : Classe parametree (template)
// NOTE     : Pour les templates C++, declaration ET definition
//            doivent etre dans le meme fichier .h
// ================================================================

#ifndef CLIENT_H
#define CLIENT_H

#include <string>
#include <iostream>
using namespace std;

template <class T>
class Client {
    private:
        T      id;
        string nom;
        string prenom;

    public:
        // Constructeur par defaut
        Client() : nom(""), prenom("") {}

        // Constructeur par parametres
        Client(T i, string n, string p) : id(i), nom(n), prenom(p) {}

        T      getId()     const { return id;     }  // Getter id
        string getNom()    const { return nom;     }  // Getter nom
        string getPrenom() const { return prenom;  }  // Getter prenom

        void setId(T i)          { id     = i; }      // Setter id
        void setNom(string n)    { nom    = n; }      // Setter nom
        void setPrenom(string p) { prenom = p; }      // Setter prenom

        // Destructeur
        ~Client() {}
};

#endif // CLIENT_H
