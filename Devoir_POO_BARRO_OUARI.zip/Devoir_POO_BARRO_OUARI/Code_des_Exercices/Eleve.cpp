// ================================================================
// Fichier  : Eleve.cpp
// Role     : DEFINITION de la classe Eleve
// Exo 2    : Heritage
// ================================================================

#include "Eleve.h"
using namespace std;

// Appelle le constructeur par defaut de Personne
// (qui lui-meme initialise Adresse par defaut)
Eleve::Eleve() : Personne(), libelle("") {}

// Chaine des constructeurs :
// Eleve ? appelle Personne(mat, n, numRue, numPorte, tel, sec)
//       ? Personne appelle Adresse(numRue, numPorte, tel, sec)
Eleve::Eleve(int mat, string n, string lib,
             string numRue, int numPorte,
             string tel, string sec
             )
    : Personne(mat, n, numRue, numPorte, tel, sec), libelle(lib) {}

string Eleve::getLibelle() const     { return libelle;  }
void   Eleve::setLibelle(string lib) { libelle = lib;   }

Eleve::~Eleve() {}
