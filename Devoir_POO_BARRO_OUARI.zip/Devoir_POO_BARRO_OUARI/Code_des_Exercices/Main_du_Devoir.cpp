// ================================================================
// Fichier  : main.cpp
// Role     : MENU PRINCIPAL - Tests des 4 exercices
// Universite Nazi BONI - LSI 2 - Programmation Avancee C++
// ================================================================

#include <iostream>
#include <vector>
#include "Livre.h"
#include "Adresse.h"
#include "Personne.h"
#include "Eleve.h"
#include "Client.h"
using namespace std;


// ================================================================
// EXERCICE 1 : Modele DDU - Classe Livre
// ================================================================
void testExercice1() {
    cout << "\n=================================================" << endl;
    cout << "   EXERCICE 1 : Modele DDU - Classe Livre        " << endl;
    cout << "=================================================" << endl;

    cout << "\n-- Objet cree avec le constructeur par defaut --" << endl;
    Livre l1;
    l1.setISSN("978-2-07-115");
    l1.setAuteurs("NAPOLEON HILL");
    l1.setTitre("Le pouvoir de la pensees positive");
    cout << "\nAffichage via getters :" << endl;
    cout << "ISSN : " << l1.getISSN() << " | Auteurs : " << l1.getAuteurs() << " | Titre : " << l1.getTitre() << endl;

    cout << "\n-- Objet cree avec le constructeur par parametres --" << endl;
    Livre l2("978-2-07-123", "ROBERT GREENE", "Les 48 lois du pouvoir");
    cout << "\nAffichage via getters :" << endl;
    cout << "ISSN : " << l2.getISSN() << " | Auteurs : " << l2.getAuteurs() << " | Titre : " << l2.getTitre() << endl;
    
    cout << "\n-- Fin Exercice 1 (destructeurs appeles automatiquement) --" << endl;
}


// ================================================================
// EXERCICE 2 : Heritage - Adresse / Personne / Eleve
// ================================================================
void testExercice2() {
    cout << "\n=================================================" << endl;
    cout << "   EXERCICE 2 : Heritage + Composition           " << endl;
    cout << "=================================================" << endl;

    // --- Classe Adresse (independante) ---
    cout << "\n|-- Classe Adresse --|" << endl;
    cout << "\n-- Objet cree avec le constructeur par defaut --" << endl;
    Adresse a1;
    a1.setNumeroRue("Avenue de la Nation");
    a1.setNumeroPorte(12);
    a1.setTelephone("0022670123456");
    a1.setSecteur("Secteur 3");
    cout << "\nAffichage via getters :" << endl;
    cout << "  Numero de rue   : " << a1.getNumeroRue()   << endl;
    cout << "  Numero de porte : " << a1.getNumeroPorte() << endl;
    cout << "  Telephone       : " << a1.getTelephone()   << endl;
    cout << "  Secteur         : " << a1.getSecteur()     << endl;

    cout << "\n-- Objet cree avec le constructeur par parametres --" << endl;
    Adresse a2("Rue de la Republique", 5, "0022675000001", "Secteur 1");
    cout << "\nAffichage via getters :" << endl;
    cout << "  Numero de rue   : " << a2.getNumeroRue()   << endl;
    cout << "  Numero de porte : " << a2.getNumeroPorte() << endl;
    cout << "  Telephone       : " << a2.getTelephone()   << endl;
    cout << "  Secteur         : " << a2.getSecteur()     << endl;

    // --- Classe Personne (avec adresse par composition) ---
    cout << "\n|-- Classe Personne (avec Adresse par composition) --|" << endl;

    // Constructeur par defaut + setters
    Personne p1;
    p1.setMatricule(1001);
    p1.setNom("TRAORE");
    p1.setAdresse(a1);   // on affecte l'adresse via le setter
    cout << "\nAffichage via getters :" << endl;
    cout << "Matricule : " << p1.getMatricule() 
         << " | Nom : " << p1.getNom()
         << " | Rue : " << p1.getAdresse().getNumeroRue()
         << " | Porte :"<< p1.getAdresse().getNumeroPorte()
         << " | Telephone :"<< p1.getAdresse().getTelephone()
         << " | Secteur : "<< p1.getAdresse().getSecteur() << endl;
    // Constructeur par parametres
    Personne p2(1002, "DIALLO",
                "Boulevard de la Paix", 8,
                "0022676000002", "Secteur 5");
    cout << "Matricule : " << p2.getMatricule() 
         << " | Nom : " << p2.getNom()
         << " | Rue : " << p2.getAdresse().getNumeroRue()
         << " | Porte :"<< p2.getAdresse().getNumeroPorte()
         << " | Telephone :"<< p2.getAdresse().getTelephone()
         << " | Secteur : "<< p2.getAdresse().getSecteur() << endl;

    // --- Classe Eleve (herite de Personne ? herite aussi de l'adresse) ---
    cout << "\n|-- Classe Eleve (herite de Personne + Adresse) --|" << endl;

    // Constructeur par defaut + setters
    Eleve e1;
    e1.setMatricule(2025);
    e1.setNom("OUEDRAOGO");
    e1.setLibelle("Terminale A");
    e1.setAdresse(a2);   // herite du setter setAdresse() de Personne
    cout << "\nAffichage via getters :" << endl;
    cout << "   |Matricule : " << e1.getMatricule() 
         << " \n| Nom : " << e1.getNom()  
         << " \n| Libelle : " << e1.getLibelle()   
         << " \n| Numero de rue : " << e1.getAdresse().getNumeroRue()  
         << " \n| Numero de porte : " << e1.getAdresse().getNumeroPorte() 
         << " \n| Telephone : " << e1.getAdresse().getTelephone() 
         << " \n| Secteur : " << e1.getAdresse().getSecteur() << endl;

    // Constructeur par parametres
    Eleve e2(2026, "KABORE", "Terminale D",
             "Rue des Jardins", 3,
             "0022677000003", "Secteur 2"
             );
    cout << "\nAffichage via getters :" << endl;
    cout << "   | Matricule : " << e2.getMatricule() 
         << " \n| Nom : " << e2.getNom()  
         << " \n| Libelle : " << e2.getLibelle()   
         << " \n| Numero de rue : " << e2.getAdresse().getNumeroRue()  
         << " \n| Numero de porte : " << e2.getAdresse().getNumeroPorte() 
         << " \n| Telephone : " << e2.getAdresse().getTelephone() 
         << " \n| Secteur : " << e2.getAdresse().getSecteur() << endl;

    cout << "\n-- Fin Exercice 2 --" << endl;
}

// ================================================================
// EXERCICE 3 : Classe parametree - Client<T>
// ================================================================
void testExercice3() {
    cout << "\n=================================================" << endl;
    cout << "   EXERCICE 3 : Classe parametree Client<T>      " << endl;
    cout << "=================================================" << endl;

    cout << "\n-- Client<int> via constructeur par defaut + setters --" << endl;
    Client<int> c1;
    c1.setId(0017);
    c1.setNom("OUARI");
    c1.setPrenom("Cheick Ousmane");
    cout << "\nAffichage via getters :" << endl;
    cout << "Id : " << c1.getId() 
	     << " | Nom : " << c1.getNom()
         << " | Prenom : " << c1.getPrenom() << endl;


    cout << "\n-- Client<string> via constructeur par parametres --" << endl;
    Client<string> c2("N0018", "BARRO", "Balamoussa");
    cout << "\nAffichage via getters :" << endl;
    cout << "Id : " << c2.getId() 
	     << " | Nom : " << c2.getNom()
         << " | Prenom : " << c2.getPrenom() << endl;
         
    cout << "\n-- Fin Exercice 3 (destructeurs appeles automatiquement) --" << endl;
}


// ================================================================
// EXERCICE 4 : STL - vector<Eleve>
// ================================================================
void testExercice4() {
    int n, mat, numPorte;
    string nom, lib, numRue, tel, secteur;
    
    cout << "\n=================================================" << endl;
    cout << "   EXERCICE 4 : STL - vector<Eleve>              " << endl;
    cout << "=================================================" << endl;

    cout << "\nEntrer le nombre d'eleves a saisir : ";
    cin >> n;

    vector<Eleve> listeEleves;

    cout << "\n-- Saisie de(s) " << n << " eleve(s) --" << endl;
    for (int i = 0; i < n; i++) {
        cout << "\n-->Eleve " << (i + 1) << " :" << endl;
        cout << "  |Matricule : "; cin >> mat;
        cout << "  |Nom       : "; cin >> nom;
        cout << "  |Libelle   : "; cin >> lib;

        cout << "  -- Adresse --" << endl;
        cout << "    |Numero rue : "; cin >> numRue;
        cout << "    |Numero porte : "; cin >> numPorte;
        cout << "    |Telephone : "; cin >> tel;
        cout << "    |Secteur : "; cin >> secteur;
        
        Eleve e(mat, nom, lib, numRue, numPorte, tel, secteur);
        listeEleves.push_back(e);
    }

    cout << "\n-- Affichage de la liste de(s) " << listeEleves.size() << " eleve(s) --" << endl;
    for (int i = 0; i < (int)listeEleves.size(); i++) {
        cout << "  Eleve " << (i + 1) << " : "
             << "Matricule = " << listeEleves[i].getMatricule()
             << " | Nom = "     << listeEleves[i].getNom()
             << " | Libelle = " << listeEleves[i].getLibelle()
             << " | Adresse = " << listeEleves[i].getAdresse().getNumeroRue() << ", "
                                << listeEleves[i].getAdresse().getNumeroPorte() << ", "
                                << listeEleves[i].getAdresse().getTelephone() << ", "
                                << listeEleves[i].getAdresse().getSecteur()
             << endl;
    }

     cout << "\n-- Fin Exercice 4 (destructeurs appeles automatiquement) --" << endl;
}

// ================================================================
// MENU PRINCIPAL
// ================================================================
void afficherMenu() {
	cout << "\n**********************************************" << endl;
    cout << "*  CE MENU PERMET DE TESTER CHAQUE EXERCICE  *" << endl;
    cout << "**********************************************" << endl;
    cout << " " << endl;
    cout << "\n=========================================" << endl;
    cout <<   "||        MENU PRINCIPAL               ||" << endl;
    cout <<   "=========================================" << endl;
    cout <<   "||  1. Exercice 1 - Classe Livre (DDU) ||" << endl;
    cout <<   "||  2. Exercice 2 - Heritage           ||" << endl;
    cout <<   "||  3. Exercice 3 - Classe parametree  ||" << endl;
    cout <<   "||  4. Exercice 4 - STL vector<Eleve>  ||" << endl;
    cout <<   "||  0. Quitter                         ||" << endl;
    cout <<   "=========================================" << endl;
    cout <<   "Votre choix : ";
}

int main() {
    int choix;

    do {
        afficherMenu();
        cin >> choix;

        switch (choix) {
            case 1: testExercice1(); break;
            case 2: testExercice2(); break;
            case 3: testExercice3(); break;
            case 4: testExercice4(); break;
            case 0: cout << "\nAu revoir Merci !!!" << endl; break;
            default:
                cout << "\nChoix invalide. Entrez un nombre entre 0 et 4." << endl;
        }

    } while (choix != 0);

    return 0;
}
