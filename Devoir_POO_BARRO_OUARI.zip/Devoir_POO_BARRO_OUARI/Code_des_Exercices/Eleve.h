// ================================================================
// Fichier  : Eleve.h
// Role     : DECLARATION de la classe Eleve (herite de Personne)
// Exo 2    : Heritage
// ================================================================

#ifndef ELEVE_H
#define ELEVE_H

#include "Personne.h"

class Eleve : public Personne {
    private:
        string libelle;

    public:
        Eleve();
        Eleve(int mat, string n, string lib,
              string numRue, int numPorte,
              string tel, string sec
              );

        string getLibelle() const;
        void   setLibelle(string lib);

        ~Eleve();
};

#endif // ELEVE_H
