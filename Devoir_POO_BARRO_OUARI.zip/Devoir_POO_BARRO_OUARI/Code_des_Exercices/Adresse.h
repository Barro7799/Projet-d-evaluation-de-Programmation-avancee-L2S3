// ================================================================
// Fichier  : Adresse.h
// Role     : DECLARATION de la classe Adresse
// Exo 2    : Heritage
// ================================================================

#ifndef ADRESSE_H
#define ADRESSE_H

#include <string>
using namespace std;

class Adresse {
    private:
        string numeroRue;
        int    numeroPorte;
        string telephone;
        string secteur;

    public:
        Adresse();                                                    // Constructeur par defaut
        Adresse(string numRue, int numPorte, string tel, string sec); // Constructeur par parametres

        string getNumeroRue()   const;   // Getter numeroRue
        int    getNumeroPorte() const;   // Getter numeroPorte
        string getTelephone()   const;   // Getter telephone
        string getSecteur()     const;   // Getter secteur

        void setNumeroRue(string numRue);   // Setter numeroRue
        void setNumeroPorte(int numPorte);  // Setter numeroPorte
        void setTelephone(string tel);      // Setter telephone
        void setSecteur(string sec);        // Setter secteur

        ~Adresse();   // Destructeur
};

#endif // ADRESSE_H
