// ================================================================
// Fichier  : Personne.cpp
// Role     : DEFINITION de la classe Personne
// Exo 2    : Heritage + Composition
// ================================================================

#include "Personne.h"
using namespace std;

// Le constructeur par defaut initialise adresse via
// le constructeur par defaut d'Adresse (automatique)
Personne::Personne() : matricule(0), nom("") {}

// On cree un objet Adresse avec les 4 parametres recus
// et on l'affecte a l'attribut adresse via la liste d'initialisation
Personne::Personne(int mat, string n,
                   string numRue, int numPorte,
                   string tel, string sec)
    : matricule(mat), nom(n),
      adresse(numRue, numPorte, tel, sec) {}

int     Personne::getMatricule() const { return matricule; }
string  Personne::getNom()       const { return nom;       }
Adresse Personne::getAdresse()   const { return adresse;   }

void Personne::setMatricule(int mat)  { matricule = mat; }
void Personne::setNom(string n)       { nom = n;         }
void Personne::setAdresse(Adresse a)  { adresse = a;     }

Personne::~Personne() {}
