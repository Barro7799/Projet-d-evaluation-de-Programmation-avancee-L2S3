// ================================================================
// Fichier  : Adresse.cpp
// Role     : DEFINITION de la classe Adresse
// Exo 2    : Heritage
// ================================================================

#include "Adresse.h"
#include <iostream>
using namespace std;

Adresse::Adresse() : numeroRue(""), numeroPorte(0), telephone(""), secteur("") {}

Adresse::Adresse(string numRue, int numPorte, string tel, string sec)
    : numeroRue(numRue), numeroPorte(numPorte), telephone(tel), secteur(sec) {}

string Adresse::getNumeroRue()   const { return numeroRue;   }
int    Adresse::getNumeroPorte() const { return numeroPorte; }
string Adresse::getTelephone()   const { return telephone;   }
string Adresse::getSecteur()     const { return secteur;     }

void Adresse::setNumeroRue(string numRue)    { numeroRue   = numRue;   }
void Adresse::setNumeroPorte(int numPorte)   { numeroPorte = numPorte; }
void Adresse::setTelephone(string tel)       { telephone   = tel;      }
void Adresse::setSecteur(string sec)         { secteur     = sec;      }

Adresse::~Adresse() {}
