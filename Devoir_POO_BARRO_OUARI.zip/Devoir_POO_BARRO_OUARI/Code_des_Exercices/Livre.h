// ================================================================
// Fichier  : Livre.h
// Role     : DECLARATION de la classe Livre
// Exo 1    : Modele DDU
// ================================================================

#ifndef LIVRE_H
#define LIVRE_H

#include <string>
using namespace std;

class Livre {
    private:
        string ISSN;
        string auteurs;
        string titre;

    public:
        Livre();                                     // Constructeur par defaut
        Livre(string issn, string aut, string tit);  // Constructeur par parametres

        string getISSN()    const;   // Getter ISSN (const permet de faire en sorte que cette m�thode ne modifie PAS l'objet)
        string getAuteurs() const;   // Getter auteurs
        string getTitre()   const;   // Getter titre

        void setISSN(string issn);   // Setter ISSN
        void setAuteurs(string aut); // Setter auteurs
        void setTitre(string tit);   // Setter titre

        ~Livre();                    // Destructeur
};

#endif // LIVRE_H
