// ================================================================
// Fichier  : Personne.h
// Role     : DECLARATION de la classe Personne
// Exo 2    : Heritage + Composition (Personne possede une Adresse)
// ================================================================

#ifndef PERSONNE_H
#define PERSONNE_H

#include <string>
#include "Adresse.h"   // composition : Personne possede une Adresse
using namespace std;

class Personne {
    private:
        int     matricule;
        string  nom;
        Adresse adresse;   // attribut de composition

    public:
        Personne();
        Personne(int mat, string n,
                 string numRue, int numPorte,
                 string tel, string sec);

        int     getMatricule() const;
        string  getNom()       const;
        Adresse getAdresse()   const;   // getter adresse

        void setMatricule(int mat);
        void setNom(string n);
        void setAdresse(Adresse a);     // setter adresse

        ~Personne();
};

#endif // PERSONNE_H
